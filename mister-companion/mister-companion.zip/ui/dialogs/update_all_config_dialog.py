from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core.open_helpers import open_uri
from core.retroaccount import (
    get_retroaccount_status,
    poll_retroaccount_login,
    start_retroaccount_login,
)
from core.update_all_config import (
    load_update_all_config,
    load_update_all_config_local,
    save_update_all_config,
    save_update_all_config_local,
)
from ui.dialogs.manuals_db_config_dialog import ManualsDbConfigDialog
from ui.dialogs.extra_sources_dialog import (
    ExtraSourceEditorDialog,
    ManageExtraSourcesDialog,
)


class UpdateAllConfigDialog(QDialog):
    def __init__(self, connection=None, parent=None, sd_root=None):
        super().__init__(parent)
        self.connection = connection
        self.sd_root = sd_root
        self.offline_mode = bool(sd_root)

        self.manualsdb_selected = []
        self.custom_sources = []
        self.custom_source_checks = []
        self.custom_sources_unmanaged_text = ""

        self.retro_pending_code = ""
        self.retro_pending_link = ""
        self.retro_seconds_remaining = 0

        self.retro_poll_timer = QTimer(self)
        self.retro_poll_timer.setInterval(5000)
        self.retro_poll_timer.timeout.connect(self.on_retro_poll_timeout)

        self.retro_countdown_timer = QTimer(self)
        self.retro_countdown_timer.setInterval(1000)
        self.retro_countdown_timer.timeout.connect(self.on_retro_countdown_timeout)

        self.setWindowTitle("Update_All Configuration")
        self.resize(900, 850)
        self.setMinimumSize(760, 500)

        self.build_ui()
        self.load_current_config()
        self.load_retro_status()

    def build_ui(self):
        self.setObjectName("UpdateAllConfigDialog")
        self.setStyleSheet(
            """
            QDialog#UpdateAllConfigDialog QScrollArea,
            QDialog#UpdateAllConfigDialog QScrollArea > QWidget > QWidget,
            QDialog#UpdateAllConfigDialog QWidget#UpdateAllConfigContent {
                background: transparent;
                border: none;
            }

            QDialog#UpdateAllConfigDialog QGroupBox#UpdateAllConfigCard {
                background-color: palette(alternate-base);
                border: 1px solid palette(button);
                border-radius: 12px;
                margin-top: 18px;
                padding: 14px;
                font-weight: 700;
            }

            QDialog#UpdateAllConfigDialog QGroupBox#UpdateAllConfigCard::title {
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 14px;
                padding: 0px 7px;
                background: transparent;
                color: palette(highlight);
            }

            QDialog#UpdateAllConfigDialog QLabel#OfflineNotice {
                color: palette(highlight);
            }

            QDialog#UpdateAllConfigDialog QLabel#MutedText {
                color: palette(mid);
            }
            """
        )

        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 18, 18, 16)
        outer.setSpacing(12)

        title = QLabel("Update_All Configuration")
        title.setStyleSheet("font-weight: 700; font-size: 19px;")
        outer.addWidget(title)

        if self.offline_mode:
            offline_label = QLabel(
                "Offline Mode: configuration will be saved directly to the selected SD card."
            )
            offline_label.setObjectName("OfflineNotice")
            offline_label.setWordWrap(True)
            outer.addWidget(offline_label)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        outer.addWidget(scroll, 1)

        content = QWidget()
        content.setObjectName("UpdateAllConfigContent")
        self.content_layout = QVBoxLayout(content)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(12)
        scroll.setWidget(content)

        columns_layout = QHBoxLayout()
        columns_layout.setSpacing(14)
        self.content_layout.addLayout(columns_layout)

        self.left_column_layout = QVBoxLayout()
        self.left_column_layout.setSpacing(12)

        self.right_column_layout = QVBoxLayout()
        self.right_column_layout.setSpacing(12)

        columns_layout.addLayout(self.left_column_layout, 3)
        columns_layout.addLayout(self.right_column_layout, 2)

        main_group = self._group("Main Cores", self.left_column_layout)
        self.main_cores_check = QCheckBox("Enable Main Cores")
        self.main_source_combo = QComboBox()
        self.main_source_combo.addItems([
            "MiSTer-devel (Recommended)",
            "DB9 / SNAC8 forks with ENCC",
            "AitorGomez fork",
        ])
        self._add(main_group, self.main_cores_check)

        row = QHBoxLayout()
        row.addSpacing(20)
        row.addWidget(QLabel("Source:"))
        row.addWidget(self.main_source_combo)
        row.addStretch()
        main_group.layout().addLayout(row)

        jt_group = self._group("JTCores", self.left_column_layout)
        self.jtcores_check = QCheckBox("Enable JTCores")
        self.jt_beta_check = QCheckBox("Enable Beta Cores")
        self._add(jt_group, self.jtcores_check)
        self._add(jt_group, self.jt_beta_check, indent=True)
        self.jtcores_check.toggled.connect(self.update_jt_beta_state)

        other_group = self._group("Other Cores", self.left_column_layout)
        self.coinop_check = QCheckBox("Coin-Op Collection")
        self.arcade_offset_check = QCheckBox("Arcade Offset Folder")
        self.llapi_check = QCheckBox("LLAPI Forks Folder")
        self.unofficial_check = QCheckBox("Unofficial Distribution")
        self.yc_check = QCheckBox("Y/C Builds")
        self.agg23_check = QCheckBox("agg23’s MiSTer Cores")
        self.altcores_check = QCheckBox("Alt Cores")
        self.dualram_check = QCheckBox("Dual RAM Console Cores")
        self.retroachievements_cores_check = QCheckBox("RetroAchievement Cores")

        for widget in [
            self.coinop_check,
            self.arcade_offset_check,
            self.llapi_check,
            self.unofficial_check,
            self.yc_check,
            self.agg23_check,
            self.altcores_check,
            self.dualram_check,
            self.retroachievements_cores_check,
        ]:
            self._add(other_group, widget)

        extra_cores_group = self._group("Extra Cores", self.left_column_layout)
        self.physical_disc_check = QCheckBox("Physical CD Support")
        self.paprium_megadrive_check = QCheckBox("Paprium MegaDrive")
        self.mms2_gb_core_check = QCheckBox("MMS2 GB Core")
        self.megavgmdrive_check = QCheckBox("MegaVGMDrive")
        for widget in [
            self.physical_disc_check,
            self.paprium_megadrive_check,
            self.mms2_gb_core_check,
            self.megavgmdrive_check,
        ]:
            self._add(extra_cores_group, widget)

        hybrid_group = self._group("Hybrid Cores", self.left_column_layout)
        self.dreamster_check = QCheckBox("DreamSTer")
        self.sonic_mania_mister_check = QCheckBox("Sonic Mania MiSTer")
        self.mister_duke3d_check = QCheckBox("MiSTer Duke3D")
        self.mister_quake_check = QCheckBox("MiSTer Quake")
        self.solarus_mister_check = QCheckBox("Solarus MiSTer")
        self.three_s_arm_check = QCheckBox("3S-ARM")
        self.mister_frontier_check = QCheckBox("MiSTer Frontier")

        self.mister_frontier_source_combo = QComboBox()
        self.mister_frontier_source_combo.addItems([
            "All Frontier Cores",
            "PICO-8 only",
            "OpenBOR 4086 only",
            "OpenBOR 7533 only",
            "OpenBOR 4086 + 7533",
            "PICO-8 + OpenBOR 4086",
            "PICO-8 + OpenBOR 7533",
        ])

        for widget in [
            self.dreamster_check,
            self.sonic_mania_mister_check,
            self.mister_duke3d_check,
            self.mister_quake_check,
            self.solarus_mister_check,
            self.three_s_arm_check,
            self.mister_frontier_check,
        ]:
            self._add(hybrid_group, widget)

        frontier_row = QHBoxLayout()
        frontier_row.addSpacing(20)
        frontier_row.addWidget(QLabel("Filter:"))
        frontier_row.addWidget(self.mister_frontier_source_combo)
        frontier_row.addStretch()
        hybrid_group.layout().addLayout(frontier_row)
        self.mister_frontier_check.toggled.connect(self.update_mister_frontier_state)

        tools_group = self._group("Tools & Scripts", self.left_column_layout)
        self.arcade_org_check = QCheckBox("Arcade Organizer")
        self.mrext_check = QCheckBox("MiSTer Extensions (Wizzo Scripts)")
        self.sam_check = QCheckBox("MiSTer Super Attract Mode")
        self.tty2oled_check = QCheckBox("tty2oled Add-on Script")
        self.i2c2oled_check = QCheckBox("i2c2oled Add-on Script")
        self.retrospy_check = QCheckBox("RetroSpy Utility")
        self.zaparoo_check = QCheckBox("Zaparoo")
        self.zaparoo_frontend_check = QCheckBox("Enable Zaparoo Frontend")
        self.anime0t4ku_mister_scripts_check = QCheckBox("Anime0t4ku MiSTer Scripts")
        self.test_suite_240p_check = QCheckBox("240P Test Suites")
        self.mister_hifi_check = QCheckBox("MiSTer Hi-Fi")
        self.misterfin_check = QCheckBox("MiSTerFin")

        for widget in [
            self.arcade_org_check,
            self.mrext_check,
            self.sam_check,
            self.tty2oled_check,
            self.i2c2oled_check,
            self.retrospy_check,
            self.zaparoo_check,
        ]:
            self._add(tools_group, widget)

        self._add(tools_group, self.zaparoo_frontend_check, indent=True)
        self._add(tools_group, self.anime0t4ku_mister_scripts_check)
        self._add(tools_group, self.test_suite_240p_check)
        self._add(tools_group, self.mister_hifi_check)
        self._add(tools_group, self.misterfin_check)

        extra_group = self._group("Extra Content", self.left_column_layout)
        self.bios_check = QCheckBox("BIOS Database")
        self.arcade_roms_check = QCheckBox("Arcade ROMs Database")
        self.bootroms_check = QCheckBox("Uberyoji Boot ROMs")
        self.gba_borders_check = QCheckBox("Dinierto GBA Borders")
        self.anime0t4ku_wallpapers_check = QCheckBox("Anime0t4ku Wallpapers")
        self.pcn_challenge_wallpapers_check = QCheckBox("PCN Challenge Wallpapers")
        self.ranny_wallpapers_check = QCheckBox("Ranny Snice Wallpapers")
        self.manualsdb_check = QCheckBox("Game Manuals (EN) DB's")
        self.manualsdb_config_button = QPushButton("Configure")

        self.ranny_wallpapers_source_combo = QComboBox()
        self.ranny_wallpapers_source_combo.addItems([
            "16:9 Wallpapers",
            "4:3 Wallpapers",
            "All Wallpapers",
        ])

        for widget in [
            self.bios_check,
            self.arcade_roms_check,
            self.bootroms_check,
            self.gba_borders_check,
            self.anime0t4ku_wallpapers_check,
            self.pcn_challenge_wallpapers_check,
            self.ranny_wallpapers_check,
        ]:
            self._add(extra_group, widget)

        wallpaper_row = QHBoxLayout()
        wallpaper_row.addSpacing(20)
        wallpaper_row.addWidget(QLabel("Source:"))
        wallpaper_row.addWidget(self.ranny_wallpapers_source_combo)
        wallpaper_row.addStretch()
        extra_group.layout().addLayout(wallpaper_row)
        self.ranny_wallpapers_check.toggled.connect(self.update_wallpaper_state)

        manualsdb_row = QHBoxLayout()
        manualsdb_row.addWidget(self.manualsdb_check)
        manualsdb_row.addStretch()
        manualsdb_row.addWidget(self.manualsdb_config_button)
        extra_group.layout().addLayout(manualsdb_row)

        self.manualsdb_check.toggled.connect(self.update_manualsdb_state)
        self.manualsdb_config_button.clicked.connect(self.on_manualsdb_configure)

        retro_group = self._group("RetroAccount", self.right_column_layout)
        retro_group.setSizePolicy(
            QSizePolicy.Policy.Preferred,
            QSizePolicy.Policy.Maximum,
        )

        self.retro_status_label = QLabel("Status: Not logged in")
        self.retro_status_label.setStyleSheet("font-weight: bold;")
        retro_group.layout().addWidget(self.retro_status_label)

        self.retro_normal_widget = QWidget()
        retro_normal_layout = QVBoxLayout(self.retro_normal_widget)
        retro_normal_layout.setContentsMargins(0, 0, 0, 0)
        retro_normal_layout.setSpacing(6)

        self.retro_description_label = QLabel(
            "Log in to this MiSTer device with your RetroAccount to enable "
            "premium update_all features."
        )
        self.retro_description_label.setWordWrap(True)
        retro_normal_layout.addWidget(self.retro_description_label)

        self.retro_login_button = QPushButton("Login")
        retro_normal_layout.addWidget(self.retro_login_button)

        self.retro_device_id_title_label = QLabel("Device ID:")
        self.retro_device_id_title_label.setStyleSheet("font-weight: bold;")
        retro_normal_layout.addWidget(self.retro_device_id_title_label)

        self.retro_device_id_value_label = QLabel("—")
        self.retro_device_id_value_label.setWordWrap(True)
        self.retro_device_id_value_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        retro_normal_layout.addWidget(self.retro_device_id_value_label)

        retro_group.layout().addWidget(self.retro_normal_widget)

        self.retro_login_widget = QWidget()
        retro_login_layout = QVBoxLayout(self.retro_login_widget)
        retro_login_layout.setContentsMargins(0, 0, 0, 0)
        retro_login_layout.setSpacing(6)

        self.retro_countdown_label = QLabel("Time remaining: 05:00")
        self.retro_countdown_label.setStyleSheet("font-weight: bold;")
        retro_login_layout.addWidget(self.retro_countdown_label)

        self.retro_code_title_label = QLabel("Code:")
        self.retro_code_title_label.setStyleSheet("font-weight: bold;")
        retro_login_layout.addWidget(self.retro_code_title_label)

        self.retro_code_value_label = QLabel("—")
        self.retro_code_value_label.setWordWrap(True)
        self.retro_code_value_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        retro_login_layout.addWidget(self.retro_code_value_label)

        self.retro_url_title_label = QLabel("Login URL:")
        self.retro_url_title_label.setStyleSheet("font-weight: bold;")
        retro_login_layout.addWidget(self.retro_url_title_label)

        self.retro_url_value_label = QLabel("—")
        self.retro_url_value_label.setWordWrap(True)
        self.retro_url_value_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        retro_login_layout.addWidget(self.retro_url_value_label)

        self.retro_login_info_label = QLabel(
            "Your browser should open automatically. Finish the login flow on "
            "RetroAccount. No further action is needed here unless the browser did not open."
        )
        self.retro_login_info_label.setWordWrap(True)
        retro_login_layout.addWidget(self.retro_login_info_label)

        retro_button_row = QHBoxLayout()
        self.retro_copy_url_button = QPushButton("Copy URL")
        self.retro_cancel_button = QPushButton("Cancel")
        retro_button_row.addWidget(self.retro_copy_url_button)
        retro_button_row.addWidget(self.retro_cancel_button)
        retro_login_layout.addLayout(retro_button_row)

        retro_group.layout().addWidget(self.retro_login_widget)
        self._set_retro_ui_state("idle")

        extra_sources_group = self._group("Extra Sources", self.right_column_layout)
        extra_sources_group.setSizePolicy(
            QSizePolicy.Policy.Preferred,
            QSizePolicy.Policy.Maximum,
        )
        extra_sources_description = QLabel(
            "Manage custom Downloader databases. The source list is shared, "
            "while selections are saved per MiSTer."
        )
        extra_sources_description.setWordWrap(True)
        extra_sources_group.layout().addWidget(extra_sources_description)

        self.custom_sources_widget = QWidget()
        self.custom_sources_layout = QVBoxLayout(self.custom_sources_widget)
        self.custom_sources_layout.setContentsMargins(0, 0, 0, 0)
        self.custom_sources_layout.setSpacing(6)
        extra_sources_group.layout().addWidget(self.custom_sources_widget)

        extra_sources_buttons = QHBoxLayout()
        self.add_custom_source_button = QPushButton("Add")
        self.edit_custom_sources_button = QPushButton("Edit")
        extra_sources_buttons.addWidget(self.add_custom_source_button)
        extra_sources_buttons.addWidget(self.edit_custom_sources_button)
        extra_sources_buttons.addStretch()
        extra_sources_group.layout().addLayout(extra_sources_buttons)

        self.add_custom_source_button.clicked.connect(self.on_add_custom_source)
        self.edit_custom_sources_button.clicked.connect(self.on_edit_custom_sources)
        self._refresh_custom_sources()
        self.right_column_layout.addStretch()

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        outer.addWidget(line)

        button_row = QHBoxLayout()
        button_row.addStretch()

        self.save_button = QPushButton("Save")
        self.close_button = QPushButton("Close")

        button_row.addWidget(self.save_button)
        button_row.addWidget(self.close_button)
        button_row.addStretch()

        outer.addLayout(button_row)

        self.save_button.clicked.connect(self.on_save)
        self.close_button.clicked.connect(self.reject)

        self.retro_login_button.clicked.connect(self.on_retro_login)
        self.retro_copy_url_button.clicked.connect(self.on_retro_copy_url)
        self.retro_cancel_button.clicked.connect(self.on_retro_cancel)

    def _group(self, title, target_layout=None):
        box = QGroupBox(title)
        box.setObjectName("UpdateAllConfigCard")
        layout = QVBoxLayout(box)
        layout.setContentsMargins(16, 20, 16, 14)
        layout.setSpacing(7)

        if target_layout is None:
            self.content_layout.addWidget(box)
        else:
            target_layout.addWidget(box)

        return box

    def _add(self, group, widget, indent=False):
        if indent:
            row = QHBoxLayout()
            row.addSpacing(20)
            row.addWidget(widget)
            row.addStretch()
            group.layout().addLayout(row)
        else:
            group.layout().addWidget(widget)

    def _format_retro_time(self):
        minutes = self.retro_seconds_remaining // 60
        seconds = self.retro_seconds_remaining % 60
        return f"{minutes:02d}:{seconds:02d}"

    def _set_retro_ui_state(self, state):
        if state == "offline":
            self.retro_status_label.setText("Status: Unavailable in Offline Mode")
            self.retro_description_label.setText(
                "RetroAccount login is only available in Online / SSH Mode.\n\n"
                "RetroAccount needs to register the MiSTer’s device ID during the login process, "
                "so the MiSTer must be connected and reachable over SSH.\n\n"
                "You can still configure update_all sources on the selected SD card in Offline Mode."
            )
            self.retro_normal_widget.show()
            self.retro_login_widget.hide()
            self.retro_device_id_title_label.hide()
            self.retro_device_id_value_label.hide()
            self.retro_device_id_value_label.setText("—")
            self.retro_login_button.setEnabled(False)

        elif state == "idle":
            self.retro_status_label.setText("Status: Not logged in")
            self.retro_description_label.setText(
                "Log in to this MiSTer device with your RetroAccount to enable "
                "premium update_all features."
            )
            self.retro_normal_widget.show()
            self.retro_login_widget.hide()
            self.retro_device_id_title_label.hide()
            self.retro_device_id_value_label.hide()
            self.retro_device_id_value_label.setText("—")
            self.retro_login_button.setEnabled(True)

        elif state == "pending":
            self.retro_status_label.setText("Status: Waiting for login")
            self.retro_normal_widget.hide()
            self.retro_login_widget.show()
            self.retro_countdown_label.setText(f"Time remaining: {self._format_retro_time()}")

        elif state == "logged_in":
            self.retro_status_label.setText("Status: Logged in")
            self.retro_description_label.setText(
                "update_all premium features are enabled on this MiSTer device."
            )
            self.retro_normal_widget.show()
            self.retro_login_widget.hide()
            self.retro_device_id_title_label.show()
            self.retro_device_id_value_label.show()
            self.retro_login_button.setEnabled(False)
            self.retro_code_value_label.setText("—")
            self.retro_url_value_label.setText("—")

    def on_retro_login(self):
        if self.offline_mode:
            QMessageBox.information(
                self,
                "RetroAccount",
                "RetroAccount login is only available in Online / SSH Mode because it needs to register this MiSTer’s device ID.",
            )
            return

        try:
            result = start_retroaccount_login(self.connection)
            self.retro_pending_code = result["device_code"]
            self.retro_pending_link = result["url"]
            self.retro_seconds_remaining = 5 * 60

            self.retro_code_value_label.setText(result["user_code"])
            self.retro_url_value_label.setText(result["url"])
            self._set_retro_ui_state("pending")

            open_uri(result["url"])

            if not self.retro_poll_timer.isActive():
                self.retro_poll_timer.start()

            if not self.retro_countdown_timer.isActive():
                self.retro_countdown_timer.start()

        except Exception as e:
            QMessageBox.critical(self, "RetroAccount", f"Failed to start login:\n{e}")

    def on_retro_copy_url(self):
        url = self.retro_url_value_label.text().strip()
        if not url or url == "—":
            return
        QGuiApplication.clipboard().setText(url)

    def on_retro_cancel(self):
        self.retro_poll_timer.stop()
        self.retro_countdown_timer.stop()
        self.retro_pending_code = ""
        self.retro_pending_link = ""
        self.retro_seconds_remaining = 0
        self.retro_code_value_label.setText("—")
        self.retro_url_value_label.setText("—")
        self.load_retro_status()

    def on_retro_countdown_timeout(self):
        if self.retro_seconds_remaining <= 0:
            self.retro_countdown_timer.stop()
            self.retro_poll_timer.stop()
            self.retro_pending_code = ""
            QMessageBox.information(
                self,
                "RetroAccount",
                "Login timed out. Please try again.",
            )
            self.load_retro_status()
            return

        self.retro_seconds_remaining -= 1
        self.retro_countdown_label.setText(f"Time remaining: {self._format_retro_time()}")

        if self.retro_seconds_remaining <= 0:
            self.retro_countdown_timer.stop()
            self.retro_poll_timer.stop()
            self.retro_pending_code = ""
            QMessageBox.information(
                self,
                "RetroAccount",
                "Login timed out. Please try again.",
            )
            self.load_retro_status()

    def on_retro_poll_timeout(self):
        if self.offline_mode:
            self.retro_poll_timer.stop()
            return

        if not self.retro_pending_code:
            self.retro_poll_timer.stop()
            return

        try:
            result = poll_retroaccount_login(self.connection, self.retro_pending_code)

            if result["status"] == "pending":
                return

            if result["status"] == "logged_in":
                self.retro_poll_timer.stop()
                self.retro_countdown_timer.stop()
                self.retro_pending_code = ""
                self.retro_pending_link = ""
                self.retro_seconds_remaining = 0
                self._set_retro_ui_state("logged_in")
                self.retro_device_id_value_label.setText(result["device_id"])
                QMessageBox.information(
                    self,
                    "RetroAccount",
                    "This MiSTer is now logged in successfully.",
                )

        except Exception as e:
            self.retro_poll_timer.stop()
            self.retro_countdown_timer.stop()
            QMessageBox.critical(self, "RetroAccount", f"Login failed:\n{e}")
            self.load_retro_status()

    def load_retro_status(self):
        if self.offline_mode:
            self.retro_poll_timer.stop()
            self.retro_countdown_timer.stop()
            self.retro_pending_code = ""
            self.retro_pending_link = ""
            self.retro_seconds_remaining = 0
            self._set_retro_ui_state("offline")
            return

        try:
            status = get_retroaccount_status(self.connection)
        except Exception:
            self._set_retro_ui_state("idle")
            return

        self.retro_poll_timer.stop()
        self.retro_countdown_timer.stop()
        self.retro_pending_code = ""
        self.retro_pending_link = ""
        self.retro_seconds_remaining = 0

        if status["logged_in"]:
            self._set_retro_ui_state("logged_in")
            self.retro_device_id_value_label.setText(status["device_id"] or "—")
        else:
            self._set_retro_ui_state("idle")

    def update_jt_beta_state(self):
        self.jt_beta_check.setEnabled(self.jtcores_check.isChecked())

    def update_wallpaper_state(self):
        self.ranny_wallpapers_source_combo.setEnabled(self.ranny_wallpapers_check.isChecked())

    def update_mister_frontier_state(self):
        self.mister_frontier_source_combo.setEnabled(self.mister_frontier_check.isChecked())

    def update_manualsdb_state(self):
        enabled = self.manualsdb_check.isChecked()
        self.manualsdb_config_button.setEnabled(enabled)

    def _sync_custom_source_checks(self):
        for source, checkbox in zip(self.custom_sources, self.custom_source_checks):
            source["enabled"] = checkbox.isChecked()

    def _refresh_custom_sources(self):
        while self.custom_sources_layout.count():
            item = self.custom_sources_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        self.custom_source_checks = []
        if not self.custom_sources:
            empty_label = QLabel("No extra sources added.")
            empty_label.setObjectName("MutedText")
            self.custom_sources_layout.addWidget(empty_label)
        else:
            for source in self.custom_sources:
                checkbox = QCheckBox(
                    str(source.get("display_name") or source.get("database_id") or "")
                )
                checkbox.setChecked(bool(source.get("enabled", False)))
                checkbox.setToolTip(
                    f'{source.get("database_id", "")}\n{source.get("db_url", "")}'
                )
                self.custom_sources_layout.addWidget(checkbox)
                self.custom_source_checks.append(checkbox)
        self.edit_custom_sources_button.setEnabled(bool(self.custom_sources))

    def on_add_custom_source(self):
        self._sync_custom_source_checks()
        dialog = ExtraSourceEditorDialog(
            existing_ids=[source.get("database_id", "") for source in self.custom_sources],
            parent=self,
        )
        if dialog.exec() == QDialog.DialogCode.Accepted:
            source = dialog.get_source()
            source["enabled"] = True
            self.custom_sources.append(source)
            self._refresh_custom_sources()

    def on_edit_custom_sources(self):
        self._sync_custom_source_checks()
        dialog = ManageExtraSourcesDialog(self.custom_sources, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.custom_sources = dialog.get_sources()
            self._refresh_custom_sources()

    def on_manualsdb_configure(self):
        dialog = ManualsDbConfigDialog(self.manualsdb_selected, self)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.manualsdb_selected = dialog.get_selected_ids()

            if self.manualsdb_selected:
                self.manualsdb_check.setChecked(True)

            self.update_manualsdb_state()

    def load_current_config(self):
        try:
            if self.offline_mode:
                data = load_update_all_config_local(self.sd_root)
            else:
                data = load_update_all_config(self.connection)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load config:\n{e}")
            return

        self.main_cores_check.setChecked(data["main_cores"])
        self.main_source_combo.setCurrentText(data["main_source"])
        self.jtcores_check.setChecked(data["jtcores"])
        self.jt_beta_check.setChecked(data["jt_beta"])

        self.coinop_check.setChecked(data["coinop"])
        self.arcade_offset_check.setChecked(data["arcade_offset"])
        self.llapi_check.setChecked(data["llapi"])
        self.unofficial_check.setChecked(data["unofficial"])
        self.yc_check.setChecked(data["yc"])
        self.agg23_check.setChecked(data["agg23"])
        self.altcores_check.setChecked(data["altcores"])
        self.dualram_check.setChecked(data["dualram"])
        self.retroachievements_cores_check.setChecked(
            data.get("retroachievements_cores", False)
        )
        self.physical_disc_check.setChecked(data.get("physical_disc", False))
        self.paprium_megadrive_check.setChecked(data.get("paprium_megadrive", False))
        self.mms2_gb_core_check.setChecked(data.get("mms2_gb_core", False))
        self.megavgmdrive_check.setChecked(data.get("megavgmdrive", False))
        self.dreamster_check.setChecked(data.get("dreamster", False))
        self.sonic_mania_mister_check.setChecked(data.get("sonic_mania_mister", False))
        self.mister_duke3d_check.setChecked(data.get("mister_duke3d", False))
        self.mister_quake_check.setChecked(data.get("mister_quake", False))
        self.solarus_mister_check.setChecked(data.get("solarus_mister", False))
        self.three_s_arm_check.setChecked(data.get("three_s_arm", False))
        self.mister_frontier_check.setChecked(data["mister_frontier"])
        self.mister_frontier_source_combo.setCurrentText(
            data.get("mister_frontier_source", "All Frontier Cores")
        )

        self.arcade_org_check.setChecked(data["arcade_org"])
        self.mrext_check.setChecked(data["mrext"])
        self.sam_check.setChecked(data["sam"])
        self.tty2oled_check.setChecked(data["tty2oled"])
        self.i2c2oled_check.setChecked(data["i2c2oled"])
        self.retrospy_check.setChecked(data["retrospy"])
        self.zaparoo_check.setChecked(data.get("zaparoo", False))
        self.zaparoo_frontend_check.setChecked(data.get("zaparoo_frontend", False))
        self.anime0t4ku_mister_scripts_check.setChecked(data["anime0t4ku_mister_scripts"])
        self.test_suite_240p_check.setChecked(data.get("test_suite_240p", False))
        self.mister_hifi_check.setChecked(data.get("mister_hifi", False))
        self.misterfin_check.setChecked(data.get("misterfin", False))

        self.bios_check.setChecked(data["bios"])
        self.arcade_roms_check.setChecked(data["arcade_roms"])
        self.bootroms_check.setChecked(data["bootroms"])
        self.gba_borders_check.setChecked(data["gbaborders"])
        self.anime0t4ku_wallpapers_check.setChecked(data["anime0t4ku_wallpapers"])
        self.pcn_challenge_wallpapers_check.setChecked(data["pcn_challenge_wallpapers"])
        self.ranny_wallpapers_check.setChecked(data["ranny_wallpapers"])
        self.ranny_wallpapers_source_combo.setCurrentText(data["ranny_wallpapers_source"])

        self.manualsdb_selected = list(data.get("manualsdb_selected", []))
        self.manualsdb_check.setChecked(data.get("manualsdb", False))
        self.custom_sources = list(data.get("custom_sources", []))
        self.custom_sources_unmanaged_text = data.get("custom_sources_unmanaged_text", "")
        self._refresh_custom_sources()

        self.update_jt_beta_state()
        self.update_wallpaper_state()
        self.update_mister_frontier_state()
        self.update_manualsdb_state()

    def collect_config(self):
        self._sync_custom_source_checks()
        return {
            "main_cores": self.main_cores_check.isChecked(),
            "main_source": self.main_source_combo.currentText(),
            "jtcores": self.jtcores_check.isChecked(),
            "jt_beta": self.jt_beta_check.isChecked(),

            "coinop": self.coinop_check.isChecked(),
            "arcade_offset": self.arcade_offset_check.isChecked(),
            "llapi": self.llapi_check.isChecked(),
            "unofficial": self.unofficial_check.isChecked(),
            "yc": self.yc_check.isChecked(),
            "agg23": self.agg23_check.isChecked(),
            "altcores": self.altcores_check.isChecked(),
            "dualram": self.dualram_check.isChecked(),
            "retroachievements_cores": self.retroachievements_cores_check.isChecked(),
            "physical_disc": self.physical_disc_check.isChecked(),
            "paprium_megadrive": self.paprium_megadrive_check.isChecked(),
            "mms2_gb_core": self.mms2_gb_core_check.isChecked(),
            "megavgmdrive": self.megavgmdrive_check.isChecked(),
            "dreamster": self.dreamster_check.isChecked(),
            "sonic_mania_mister": self.sonic_mania_mister_check.isChecked(),
            "mister_duke3d": self.mister_duke3d_check.isChecked(),
            "mister_quake": self.mister_quake_check.isChecked(),
            "solarus_mister": self.solarus_mister_check.isChecked(),
            "three_s_arm": self.three_s_arm_check.isChecked(),
            "mister_frontier": self.mister_frontier_check.isChecked(),
            "mister_frontier_source": self.mister_frontier_source_combo.currentText(),

            "arcade_org": self.arcade_org_check.isChecked(),
            "mrext": self.mrext_check.isChecked(),
            "sam": self.sam_check.isChecked(),
            "tty2oled": self.tty2oled_check.isChecked(),
            "i2c2oled": self.i2c2oled_check.isChecked(),
            "retrospy": self.retrospy_check.isChecked(),
            "zaparoo": self.zaparoo_check.isChecked(),
            "zaparoo_frontend": self.zaparoo_frontend_check.isChecked(),
            "anime0t4ku_mister_scripts": self.anime0t4ku_mister_scripts_check.isChecked(),
            "test_suite_240p": self.test_suite_240p_check.isChecked(),
            "mister_hifi": self.mister_hifi_check.isChecked(),
            "misterfin": self.misterfin_check.isChecked(),

            "bios": self.bios_check.isChecked(),
            "arcade_roms": self.arcade_roms_check.isChecked(),
            "bootroms": self.bootroms_check.isChecked(),
            "gbaborders": self.gba_borders_check.isChecked(),
            "anime0t4ku_wallpapers": self.anime0t4ku_wallpapers_check.isChecked(),
            "pcn_challenge_wallpapers": self.pcn_challenge_wallpapers_check.isChecked(),
            "ranny_wallpapers": self.ranny_wallpapers_check.isChecked(),
            "ranny_wallpapers_source": self.ranny_wallpapers_source_combo.currentText(),
            "manualsdb": self.manualsdb_check.isChecked(),
            "manualsdb_selected": list(self.manualsdb_selected),
            "custom_sources": list(self.custom_sources),
            "custom_sources_unmanaged_text": self.custom_sources_unmanaged_text,
        }

    def on_save(self):
        try:
            if self.offline_mode:
                save_update_all_config_local(self.sd_root, self.collect_config())
            else:
                save_update_all_config(self.connection, self.collect_config())

            QMessageBox.information(self, "Saved", "update_all configuration saved successfully.")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save config:\n{e}")

    def closeEvent(self, event):
        self.retro_poll_timer.stop()
        self.retro_countdown_timer.stop()
        super().closeEvent(event)
