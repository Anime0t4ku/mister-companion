from pathlib import Path

from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox,
    QDialog,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ui.tab_header import create_tab_header
from ui.scaling import set_text_button_min_width
from core.savemanager import (
    SYNC_ROOT,
    create_backup,
    create_backup_local,
    ensure_local_save_dirs,
    ensure_remote_save_dirs,
    ensure_savemanager_dirs,
    get_backup_count,
    get_device_backup_root,
    list_backup_devices,
    open_folder,
    restore_backup,
    restore_backup_local,
    save_retention_setting,
    sync_saves,
    sync_saves_local,
)


class SaveManagerWorker(QThread):
    log = pyqtSignal(str)
    done = pyqtSignal(bool, str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            self.fn(self.log.emit)
            self.done.emit(True, "")
        except Exception as e:
            self.done.emit(False, str(e))


class RestoreBackupDialog(QDialog):
    def __init__(self, backup_devices, parent=None):
        super().__init__(parent)
        self.backup_devices = backup_devices
        self.setWindowTitle("Restore Backup")
        self.setMinimumSize(560, 390)

        layout = QVBoxLayout(self)

        info = QLabel("Choose which SaveManager backup you want to restore to the current MiSTer or selected SD Card.")
        info.setWordWrap(True)
        layout.addWidget(info)

        device_label = QLabel("Restore from device:")
        layout.addWidget(device_label)

        self.device_combo = QComboBox()
        for entry in self.backup_devices:
            self.device_combo.addItem(entry.get("name", ""))
        layout.addWidget(self.device_combo)

        backup_label = QLabel("Backup:")
        layout.addWidget(backup_label)

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        self.backup_before_restore_checkbox = QCheckBox("Backup current device before restoring")
        self.backup_before_restore_checkbox.setChecked(True)
        layout.addWidget(self.backup_before_restore_checkbox)

        button_row = QHBoxLayout()
        button_row.addStretch()

        self.restore_button = QPushButton("Restore")
        self.cancel_button = QPushButton("Cancel")

        button_row.addWidget(self.restore_button)
        button_row.addWidget(self.cancel_button)
        layout.addLayout(button_row)

        self.device_combo.currentIndexChanged.connect(self.populate_backups)
        self.restore_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        self.list_widget.itemDoubleClicked.connect(lambda _: self.accept())
        self.populate_backups()

    def populate_backups(self):
        self.list_widget.clear()
        index = self.device_combo.currentIndex()
        if index < 0 or index >= len(self.backup_devices):
            return

        backups = self.backup_devices[index].get("backups", [])
        self.list_widget.addItems(backups)
        if backups:
            self.list_widget.setCurrentRow(0)

    def selected_device(self):
        return self.device_combo.currentText().strip()

    def selected_backup(self):
        item = self.list_widget.currentItem()
        return item.text().strip() if item else ""

    def backup_before_restore(self):
        return self.backup_before_restore_checkbox.isChecked()


class MergeConfirmDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Merge Saves")
        self.setMinimumWidth(420)

        layout = QVBoxLayout(self)

        info = QLabel(
            "Merge combines local SaveManager data with the current MiSTer saves, using your PC as the middleman.\n\n"
            "Newest files are kept, then the merged result is uploaded back to the MiSTer.\n\n"
            "This is a manual merge process.\n"
            "For automatic syncing, install ftp_save_sync from the Scripts tab (requires FTP access with write permissions)."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.backup_checkbox = QCheckBox("Backup current device before merging")
        self.backup_checkbox.setChecked(True)
        layout.addWidget(self.backup_checkbox)

        button_row = QHBoxLayout()
        button_row.addStretch()

        self.merge_button = QPushButton("Merge")
        self.cancel_button = QPushButton("Cancel")

        button_row.addWidget(self.merge_button)
        button_row.addWidget(self.cancel_button)
        layout.addLayout(button_row)

        self.merge_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)

    def backup_before_merge(self):
        return self.backup_checkbox.isChecked()


class SaveManagerTab(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.connection = main_window.connection
        self.worker = None
        self._save_dirs_prepared = False
        self._prepared_mode_key = ""

        ensure_savemanager_dirs()
        self.build_ui()
        self.update_connection_state(lightweight=True)

    def build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(14)

        self.setStyleSheet(
            """
            SaveManagerTab,
            QWidget#SaveManagerContent {
                background: transparent;
            }

            QGroupBox#SaveManagerCard {
                background-color: palette(alternate-base);
                border: 1px solid palette(button);
                border-radius: 12px;
                margin-top: 18px;
                padding: 14px;
                font-weight: 700;
            }

            QGroupBox#SaveManagerCard::title {
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 14px;
                padding: 0px 7px;
                background: transparent;
                color: palette(highlight);
            }
            """
        )

        main_layout.addWidget(create_tab_header(self.main_window, "SaveManager", "savemanager"))

        content_row = QHBoxLayout()
        content_row.setContentsMargins(0, 0, 0, 0)
        content_row.setSpacing(0)
        content_row.addStretch(1)

        content_widget = QWidget()
        content_widget.setObjectName("SaveManagerContent")
        content_widget.setMaximumWidth(980)
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(14)

        main_group = QGroupBox("Save Management")
        main_group.setObjectName("SaveManagerCard")
        main_group_layout = QVBoxLayout(main_group)
        main_group_layout.setContentsMargins(18, 20, 18, 16)
        main_group_layout.setSpacing(14)

        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        self.backup_button = QPushButton("Backup Saves")
        self.restore_button = QPushButton("Restore Backup")
        self.sync_button = QPushButton("Merge Saves")

        set_text_button_min_width(self.backup_button, 115)
        set_text_button_min_width(self.restore_button, 115)
        set_text_button_min_width(self.sync_button, 115)
        button_row.addStretch()
        button_row.addWidget(self.backup_button)
        button_row.addWidget(self.restore_button)
        button_row.addWidget(self.sync_button)
        button_row.addStretch()
        main_group_layout.addLayout(button_row)

        details_row = QHBoxLayout()
        details_row.setSpacing(18)

        self.backup_count_label = QLabel("Current backups for this device: 0")
        self.backup_count_label.setAlignment(pyqt_alignment_center())

        self.retention_label = QLabel("Backups:")
        self.retention_spin = QSpinBox()
        self.retention_spin.setRange(1, 100)
        self.retention_spin.setMinimumWidth(80)
        self.retention_spin.setValue(int(self.main_window.config_data.get("backup_retention", 10)))
        self.retention_spin.valueChanged.connect(self.on_retention_changed)

        details_row.addStretch()
        details_row.addWidget(self.backup_count_label)
        details_row.addSpacing(8)
        details_row.addWidget(self.retention_label)
        details_row.addWidget(self.retention_spin)
        details_row.addStretch()
        main_group_layout.addLayout(details_row)

        content_layout.addWidget(main_group)

        folder_group = QGroupBox("Folders")
        folder_group.setObjectName("SaveManagerCard")
        folder_group_layout = QVBoxLayout(folder_group)
        folder_group_layout.setContentsMargins(18, 18, 18, 14)
        folder_group_layout.setSpacing(10)

        folder_row = QHBoxLayout()
        folder_row.setSpacing(10)

        self.open_backup_folder_button = QPushButton("Browse Backups")
        self.open_sync_folder_button = QPushButton("Browse Merge Folder")

        set_text_button_min_width(self.open_backup_folder_button, 115)
        set_text_button_min_width(self.open_sync_folder_button, 132)
        folder_row.addStretch()
        folder_row.addWidget(self.open_backup_folder_button)
        folder_row.addWidget(self.open_sync_folder_button)
        folder_row.addStretch()
        folder_group_layout.addLayout(folder_row)

        content_layout.addWidget(folder_group)

        self.log_group = QGroupBox("Log")
        self.log_group.setObjectName("SaveManagerCard")
        log_group_layout = QVBoxLayout(self.log_group)
        log_group_layout.setContentsMargins(18, 18, 18, 14)
        log_group_layout.setSpacing(10)

        log_header_row = QHBoxLayout()
        log_header_row.addStretch()
        self.hide_log_button = QPushButton("Hide")
        set_text_button_min_width(self.hide_log_button, 80)
        log_header_row.addWidget(self.hide_log_button)
        log_group_layout.addLayout(log_header_row)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMinimumHeight(180)
        log_group_layout.addWidget(self.log_output)

        content_layout.addWidget(self.log_group)
        self.log_group.hide()
        content_layout.addStretch()

        content_row.addWidget(content_widget, 1)
        content_row.addStretch(1)
        main_layout.addLayout(content_row, 1)

        self.backup_button.clicked.connect(self.backup_saves)
        self.restore_button.clicked.connect(self.restore_saves)
        self.sync_button.clicked.connect(self.sync_saves_action)
        self.open_backup_folder_button.clicked.connect(self.open_backup_folder)
        self.open_sync_folder_button.clicked.connect(self.open_sync_folder)
        self.hide_log_button.clicked.connect(self.hide_log)

    def is_offline_mode(self):
        checker = getattr(self.main_window, "is_offline_mode", None)
        return bool(checker()) if callable(checker) else False

    def get_offline_sd_root(self):
        getter = getattr(self.main_window, "get_offline_sd_root", None)
        if callable(getter):
            value = getter()
        else:
            value = self.main_window.config_data.get("offline_sd_root", "")

        value = str(value or "").strip()
        return Path(value) if value else None

    def has_offline_sd_root(self):
        root = self.get_offline_sd_root()
        return bool(root and root.exists())

    def can_use_savemanager(self):
        if self.is_offline_mode():
            return self.has_offline_sd_root()
        return self.connection.is_connected()

    def get_current_profile_name(self):
        if self.is_offline_mode():
            return "Offline SD Card"

        if hasattr(self.main_window.connection_tab, "get_selected_profile_name"):
            return self.main_window.connection_tab.get_selected_profile_name()

        return ""

    def get_current_ip(self):
        if self.is_offline_mode():
            return ""

        return getattr(self.connection, "host", "") or ""

    def _current_prepare_key(self):
        if self.is_offline_mode():
            return f"offline:{self.get_offline_sd_root()}"
        return f"online:{self.get_current_ip()}"

    def update_backup_count(self):
        count = get_backup_count(
            profile_name=self.get_current_profile_name(),
            ip_address=self.get_current_ip(),
        )
        self.backup_count_label.setText(f"Current backups for this device: {count}")

    def _set_controls_enabled(self, available: bool):
        self.backup_button.setEnabled(available)
        self.restore_button.setEnabled(available)
        self.sync_button.setEnabled(available)
        self.retention_spin.setEnabled(available)
        self.open_backup_folder_button.setEnabled(available)
        self.open_sync_folder_button.setEnabled(available)

    def update_connection_state(self, lightweight=True):
        available = self.can_use_savemanager()

        if not available:
            self._save_dirs_prepared = False
            self._prepared_mode_key = ""
            self._set_controls_enabled(False)
            self.update_backup_count()
            return

        self._set_controls_enabled(True)
        self.update_backup_count()

        if lightweight:
            return

        self.prepare_save_dirs()

    def prepare_save_dirs(self):
        if not self.can_use_savemanager():
            return False

        prepare_key = self._current_prepare_key()
        if self._save_dirs_prepared and self._prepared_mode_key == prepare_key:
            return True

        if self.is_offline_mode():
            try:
                ensure_local_save_dirs(self.get_offline_sd_root())
            except Exception as e:
                QMessageBox.warning(
                    self,
                    "SaveManager",
                    f"Could not prepare the local SD Card save folders.\n\n{e}",
                )
                self._save_dirs_prepared = False
                self._prepared_mode_key = ""
                self._set_controls_enabled(False)
                return False
        else:
            try:
                ensure_remote_save_dirs(self.connection)
            except Exception as e:
                QMessageBox.warning(
                    self,
                    "SaveManager",
                    f"Could not prepare the MiSTer save folders.\n\n{e}",
                )
                self._save_dirs_prepared = False
                self._prepared_mode_key = ""
                self._set_controls_enabled(False)
                return False

        self._save_dirs_prepared = True
        self._prepared_mode_key = prepare_key
        return True

    def refresh_status(self):
        self.update_connection_state(lightweight=False)

    def on_retention_changed(self, value):
        value = save_retention_setting(self.main_window.config_data, value)
        self.retention_spin.blockSignals(True)
        self.retention_spin.setValue(value)
        self.retention_spin.blockSignals(False)

    def show_log(self):
        if not self.log_group.isVisible():
            self.log_group.show()

    def hide_log(self):
        if self.hide_log_button.isEnabled():
            self.log_group.hide()

    def clear_log(self):
        self.log_output.clear()

    def log_message(self, text):
        self.log_output.append(text)

    def set_busy(self, busy: bool):
        enabled = not busy and self.can_use_savemanager()
        self.backup_button.setEnabled(enabled)
        self.restore_button.setEnabled(enabled)
        self.sync_button.setEnabled(enabled)
        self.retention_spin.setEnabled(enabled)
        self.open_backup_folder_button.setEnabled(enabled)
        self.open_sync_folder_button.setEnabled(enabled)
        self.hide_log_button.setEnabled(not busy)

    def start_worker(self, fn):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.warning(self, "Busy", "A SaveManager task is already running.")
            return

        self.show_log()
        self.clear_log()
        self.set_busy(True)

        self.worker = SaveManagerWorker(fn)
        self.worker.log.connect(self.log_message)
        self.worker.done.connect(self.on_worker_done)
        self.worker.start()

    def on_worker_done(self, ok: bool, error_message: str):
        self.set_busy(False)
        self.worker = None
        self.update_backup_count()

        if not ok:
            self.log_message(f"Operation failed: {error_message}")
            QMessageBox.warning(self, "SaveManager", error_message)

    def require_available(self):
        if self.is_offline_mode():
            if not self.has_offline_sd_root():
                QMessageBox.warning(self, "Error", "Select an Offline SD Card folder first.")
                return False

            if not self.prepare_save_dirs():
                return False

            return True

        if not self.connection.is_connected():
            QMessageBox.warning(self, "Error", "Connect to a MiSTer first.")
            return False

        if not self.prepare_save_dirs():
            return False

        return True

    def backup_saves(self):
        if not self.require_available():
            return

        profile_name = self.get_current_profile_name()
        ip_address = self.get_current_ip()

        if self.is_offline_mode():
            sd_root = self.get_offline_sd_root()

            def task(log):
                create_backup_local(
                    sd_root,
                    self.main_window.config_data,
                    profile_name=profile_name,
                    ip_address=ip_address,
                    log_callback=log,
                )
        else:
            def task(log):
                create_backup(
                    self.connection,
                    self.main_window.config_data,
                    profile_name=profile_name,
                    ip_address=ip_address,
                    log_callback=log,
                )

        self.start_worker(task)

    def restore_saves(self):
        if not self.require_available():
            return

        profile_name = self.get_current_profile_name()
        ip_address = self.get_current_ip()

        backup_devices = list_backup_devices()
        if not backup_devices:
            QMessageBox.warning(self, "Restore Backup", "No SaveManager backups found.")
            return

        dialog = RestoreBackupDialog(backup_devices, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        selected_device = dialog.selected_device()
        selected_backup = dialog.selected_backup()
        if not selected_device or not selected_backup:
            QMessageBox.warning(self, "Restore Backup", "Select a device and backup first.")
            return

        backup_before_restore = dialog.backup_before_restore()

        if self.is_offline_mode():
            sd_root = self.get_offline_sd_root()

            def task(log):
                if backup_before_restore:
                    log("Creating safety backup before restore...")
                    create_backup_local(
                        sd_root,
                        self.main_window.config_data,
                        profile_name=profile_name,
                        ip_address=ip_address,
                        log_callback=log,
                    )
                restore_backup_local(
                    sd_root,
                    selected_backup,
                    profile_name=profile_name,
                    ip_address=ip_address,
                    source_device_name=selected_device,
                    log_callback=log,
                )
        else:
            def task(log):
                if backup_before_restore:
                    log("Creating safety backup before restore...")
                    create_backup(
                        self.connection,
                        self.main_window.config_data,
                        profile_name=profile_name,
                        ip_address=ip_address,
                        log_callback=log,
                    )
                restore_backup(
                    self.connection,
                    selected_backup,
                    profile_name=profile_name,
                    ip_address=ip_address,
                    source_device_name=selected_device,
                    log_callback=log,
                )

        self.start_worker(task)

    def sync_saves_action(self):
        if not self.require_available():
            return

        dialog = MergeConfirmDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        backup_before_merge = dialog.backup_before_merge()
        profile_name = self.get_current_profile_name()
        ip_address = self.get_current_ip()

        if self.is_offline_mode():
            sd_root = self.get_offline_sd_root()

            def task(log):
                if backup_before_merge:
                    log("Creating safety backup before merge...")
                    create_backup_local(
                        sd_root,
                        self.main_window.config_data,
                        profile_name=profile_name,
                        ip_address=ip_address,
                        log_callback=log,
                    )
                sync_saves_local(
                    sd_root,
                    log_callback=log,
                )
        else:
            def task(log):
                if backup_before_merge:
                    log("Creating safety backup before merge...")
                    create_backup(
                        self.connection,
                        self.main_window.config_data,
                        profile_name=profile_name,
                        ip_address=ip_address,
                        log_callback=log,
                    )
                sync_saves(
                    self.connection,
                    log_callback=log,
                )

        self.start_worker(task)

    def open_backup_folder(self):
        profile_name = self.get_current_profile_name()
        ip_address = self.get_current_ip()

        target = get_device_backup_root(profile_name=profile_name, ip_address=ip_address)
        try:
            open_folder(target)
        except Exception as e:
            QMessageBox.critical(self, "Open Folder Failed", str(e))

    def open_sync_folder(self):
        try:
            open_folder(SYNC_ROOT)
        except Exception as e:
            QMessageBox.critical(self, "Open Folder Failed", str(e))


def pyqt_alignment_center():
    from PyQt6.QtCore import Qt
    return Qt.AlignmentFlag.AlignCenter
