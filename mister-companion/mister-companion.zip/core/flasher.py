from __future__ import annotations

import ctypes
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import time
import zipfile
from pathlib import Path
from urllib.parse import quote, unquote
from typing import Callable

import requests

from core.app_paths import generated_path

try:
    import winreg
except ImportError:
    winreg = None


APP_NAME = "MiSTer Companion"


ANSI_ESCAPE_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")


def clean_output(text: str) -> str:
    return ANSI_ESCAPE_RE.sub("", text)


def get_app_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = get_app_base_dir()
TOOLS_DIR = generated_path("tools", default_root=BASE_DIR)
BALENA_DIR = TOOLS_DIR / "balena-cli"
MR_FUSION_DIR = TOOLS_DIR / "mr-fusion"
MC_FUSION_DIR = TOOLS_DIR / "mc-fusion"
SUPERSTATION_DIR = TOOLS_DIR / "superstation"

BALENA_REPO = "balena-io/balena-cli"
MR_FUSION_REPO = "MiSTer-devel/mr-fusion"
MC_FUSION_REPO = "Anime0t4ku/mc-fusion"
MC_FUSION_ASSET_NAME = "mc-fusion.img.zip"
MC_FUSION_VERSION_FILE = MC_FUSION_DIR / "version.txt"
SUPERSTATION_REPO = "Retro-Remake/SuperStation-SD-Card-Installer"

GITHUB_API_BASE = "https://api.github.com/repos"
REQUEST_HEADERS = {
    "User-Agent": APP_NAME,
    "Accept": "application/vnd.github+json",
}

LogCallback = Callable[[str], None]


def _noop_log(_: str) -> None:
    pass


def _log(log_callback: LogCallback | None, message: str) -> None:
    (log_callback or _noop_log)(message)


def is_flash_supported() -> bool:
    return platform.system() in {"Windows", "Linux", "Darwin"}


def get_platform_key() -> str:
    system = platform.system()
    if system == "Windows":
        return "windows"
    if system == "Linux":
        return "linux"
    if system == "Darwin":
        return "macos"
    return "unsupported"


def get_arch_key() -> str:
    machine = platform.machine().lower()

    if machine in {"x86_64", "amd64"}:
        return "x64"
    if machine in {"aarch64", "arm64"}:
        return "arm64"

    raise RuntimeError(f"Unsupported CPU architecture: {machine}")


def _clean_subprocess_env() -> dict[str, str]:
    """
    Return a safe environment for external system tools.

    PyInstaller can modify LD_LIBRARY_PATH so the bundled libraries are preferred.
    That is useful for the app itself, but it can break external commands.

    On Arch Linux this can cause system bash to load an incompatible readline
    library, resulting in:

        bash: symbol lookup error: bash: undefined symbol: rl_print_keybinding

    For external tools like balena CLI, bash, diskutil, gio, etc. we restore the
    original library path if PyInstaller saved it, otherwise we remove the
    PyInstaller-provided LD_LIBRARY_PATH.
    """
    env = os.environ.copy()

    if platform.system() in {"Linux", "Darwin"}:
        original_ld_library_path = env.get("LD_LIBRARY_PATH_ORIG")

        if original_ld_library_path is not None:
            if original_ld_library_path:
                env["LD_LIBRARY_PATH"] = original_ld_library_path
            else:
                env.pop("LD_LIBRARY_PATH", None)
        else:
            env.pop("LD_LIBRARY_PATH", None)

        env.pop("LD_PRELOAD", None)

    return env


def is_admin_windows() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def is_root_linux() -> bool:
    try:
        return os.geteuid() == 0
    except AttributeError:
        return False


def _get_windows_autoplay_value() -> int | None:
    if platform.system() != "Windows" or winreg is None:
        return None

    try:
        key = winreg.CreateKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer",
        )
        try:
            value, _ = winreg.QueryValueEx(key, "NoDriveTypeAutoRun")
            return int(value)
        finally:
            winreg.CloseKey(key)
    except Exception:
        return None


def _set_windows_autoplay_value(value: int) -> None:
    if platform.system() != "Windows" or winreg is None:
        return

    key = winreg.CreateKey(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer",
    )
    try:
        winreg.SetValueEx(key, "NoDriveTypeAutoRun", 0, winreg.REG_DWORD, int(value))
    finally:
        winreg.CloseKey(key)


def _delete_windows_autoplay_value() -> None:
    if platform.system() != "Windows" or winreg is None:
        return

    key = winreg.CreateKey(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer",
    )
    try:
        try:
            winreg.DeleteValue(key, "NoDriveTypeAutoRun")
        except FileNotFoundError:
            pass
        except OSError:
            pass
    finally:
        winreg.CloseKey(key)


def _disable_windows_autoplay(log_callback: LogCallback | None = None) -> int | None:
    if platform.system() != "Windows":
        return None

    original_value = _get_windows_autoplay_value()
    _log(log_callback, "Temporarily disabling Windows AutoPlay...")
    _set_windows_autoplay_value(0xFF)
    return original_value


def _restore_windows_autoplay(
    original_value: int | None,
    log_callback: LogCallback | None = None,
) -> None:
    if platform.system() != "Windows":
        return

    if original_value is None:
        _delete_windows_autoplay_value()
        return

    _log(log_callback, "Windows settings restored")
    _set_windows_autoplay_value(original_value)


def _ensure_flash_privileges() -> None:
    system = platform.system()

    if system == "Windows":
        if not is_admin_windows():
            raise RuntimeError(
                "Administrator privileges are required to flash an SD card.\n\n"
                "Please restart MiSTer Companion as Administrator and try again."
            )

    elif system == "Linux":
        if not is_root_linux():
            if shutil.which("pkexec"):
                raise RuntimeError(
                    "Root privileges are required to flash an SD card.\n\n"
                    "Please run MiSTer Companion with pkexec or sudo and try again."
                )
            raise RuntimeError(
                "Root privileges are required to flash an SD card.\n\n"
                "Please run MiSTer Companion with sudo and try again."
            )


def ensure_tools_dirs(log_callback: LogCallback | None = None) -> None:
    TOOLS_DIR.mkdir(parents=True, exist_ok=True)
    BALENA_DIR.mkdir(parents=True, exist_ok=True)
    MR_FUSION_DIR.mkdir(parents=True, exist_ok=True)
    MC_FUSION_DIR.mkdir(parents=True, exist_ok=True)
    SUPERSTATION_DIR.mkdir(parents=True, exist_ok=True)
    _log(log_callback, f"Using tools directory: {TOOLS_DIR}")


def _get_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(REQUEST_HEADERS)
    return session


def _github_latest_release(repo: str) -> dict:
    url = f"{GITHUB_API_BASE}/{repo}/releases/latest"
    session = _get_session()
    response = session.get(url, timeout=30)
    response.raise_for_status()
    return response.json()


def _github_latest_release_tag_from_page(repo: str) -> str:
    url = f"https://github.com/{repo}/releases/latest"
    session = _get_session()
    response = session.get(url, timeout=30, allow_redirects=True)
    response.raise_for_status()

    final_url = response.url or ""
    match = re.search(r"/releases/tag/([^/?#]+)", final_url)
    if match:
        return unquote(match.group(1))

    match = re.search(rf"/{re.escape(repo)}/releases/tag/([^\"'<>?#]+)", response.text)
    if match:
        return unquote(match.group(1))

    raise RuntimeError(f"Could not determine the latest release tag for {repo}.")


def _github_release_asset_download_url(repo: str, tag: str, asset_name: str) -> str:
    return (
        f"https://github.com/{repo}/releases/download/"
        f"{quote(tag, safe='')}/{quote(asset_name, safe='')}"
    )


def _download_file(
    url: str,
    dest_path: Path,
    log_callback: LogCallback | None = None,
) -> Path:
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    _log(log_callback, f"Downloading {dest_path.name}...")

    session = _get_session()
    with session.get(url, stream=True, timeout=120) as response:
        response.raise_for_status()

        total_bytes = int(response.headers.get("Content-Length", 0))
        written_bytes = 0
        last_logged_percent = -1

        with dest_path.open("wb") as f:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if not chunk:
                    continue

                f.write(chunk)
                written_bytes += len(chunk)

                if total_bytes > 0:
                    percent = int((written_bytes / total_bytes) * 100)
                    if percent >= last_logged_percent + 10:
                        last_logged_percent = percent
                        _log(log_callback, f"{dest_path.name}: {percent}%")

    _log(log_callback, f"Finished downloading {dest_path.name}")
    return dest_path


def _clear_directory_contents(folder: Path) -> None:
    if not folder.exists():
        return

    for item in folder.iterdir():
        if item.is_dir():
            shutil.rmtree(item, ignore_errors=True)
        else:
            try:
                item.unlink()
            except FileNotFoundError:
                pass


def _safe_extract_tar(archive_path: Path, dest_dir: Path) -> None:
    dest_dir.mkdir(parents=True, exist_ok=True)

    with tarfile.open(archive_path, "r:*") as tar:
        resolved_dest = dest_dir.resolve()

        for member in tar.getmembers():
            member_path = dest_dir / member.name
            resolved_member = member_path.resolve()
            if not str(resolved_member).startswith(str(resolved_dest)):
                raise RuntimeError(f"Unsafe path in tar archive: {member.name}")

        tar.extractall(dest_dir)


def _extract_zip(archive_path: Path, dest_dir: Path) -> None:
    dest_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path, "r") as zf:
        zf.extractall(dest_dir)


def _extract_archive(
    archive_path: Path,
    dest_dir: Path,
    log_callback: LogCallback | None = None,
) -> None:
    _log(log_callback, f"Extracting {archive_path.name}...")

    name = archive_path.name.lower()
    if name.endswith((".tar.gz", ".tgz", ".tar")):
        _safe_extract_tar(archive_path, dest_dir)
    elif name.endswith(".zip"):
        _extract_zip(archive_path, dest_dir)
    else:
        raise RuntimeError(f"Unsupported archive format: {archive_path.name}")

    _log(log_callback, f"Finished extracting {archive_path.name}")

    try:
        archive_path.unlink()
        _log(log_callback, f"Removed archive: {archive_path.name}")
    except FileNotFoundError:
        pass


def _make_executable(path: Path) -> None:
    if not path.exists():
        return

    current_mode = path.stat().st_mode
    path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _find_first_matching_file(root: Path, pattern: str) -> Path | None:
    matches = sorted(p for p in root.rglob(pattern) if p.is_file())
    return matches[0] if matches else None


def _find_newest_matching_file(root: Path, pattern: str) -> Path | None:
    matches = [p for p in root.rglob(pattern) if p.is_file()]
    if not matches:
        return None
    return max(matches, key=lambda p: p.stat().st_mtime)


def has_balena_cli() -> bool:
    try:
        get_balena_executable()
        return True
    except Exception:
        return False


def has_mr_fusion_image() -> bool:
    try:
        get_mr_fusion_image()
        return True
    except Exception:
        return False


def has_mc_fusion_image() -> bool:
    try:
        get_mc_fusion_image()
        return True
    except Exception:
        return False


def has_superstation_image() -> bool:
    try:
        get_superstation_image()
        return True
    except Exception:
        return False


def get_balena_executable() -> Path:
    platform_key = get_platform_key()

    if platform_key == "windows":
        exe = _find_first_matching_file(BALENA_DIR, "balena.cmd")
        if exe:
            return exe

    if platform_key in {"linux", "macos"}:
        exe = _find_first_matching_file(BALENA_DIR, "balena")
        if exe:
            return exe

    raise RuntimeError("balena CLI executable not found. Download it first.")


def get_mr_fusion_image() -> Path:
    image = _find_first_matching_file(MR_FUSION_DIR, "*.img")
    if image:
        return image

    raise RuntimeError("Mr. Fusion image not found. Download it first.")


def get_mc_fusion_image() -> Path:
    image = _find_first_matching_file(MC_FUSION_DIR, "*.img")
    if image:
        return image

    raise RuntimeError("MC-Fusion image not found. Download it first.")


def get_superstation_image() -> Path:
    image = _find_first_matching_file(SUPERSTATION_DIR, "*.img")
    if image:
        return image

    raise RuntimeError("SuperStation image not found. Download it first.")


def remove_balena_cli(log_callback: LogCallback | None = None) -> None:
    ensure_tools_dirs(log_callback)
    _clear_directory_contents(BALENA_DIR)
    _log(log_callback, "Removed balena CLI files.")


def remove_mr_fusion_image(log_callback: LogCallback | None = None) -> None:
    ensure_tools_dirs(log_callback)
    _clear_directory_contents(MR_FUSION_DIR)
    _log(log_callback, "Removed Mr. Fusion files.")


def remove_mc_fusion_image(log_callback: LogCallback | None = None) -> None:
    ensure_tools_dirs(log_callback)
    _clear_directory_contents(MC_FUSION_DIR)
    _log(log_callback, "Removed MC-Fusion files.")


def remove_superstation_image(log_callback: LogCallback | None = None) -> None:
    ensure_tools_dirs(log_callback)
    _clear_directory_contents(SUPERSTATION_DIR)
    _log(log_callback, "Removed SuperStation files.")


def _select_balena_asset(release_data: dict) -> dict:
    platform_key = get_platform_key()
    arch_key = get_arch_key()

    if platform_key not in {"windows", "linux", "macos"}:
        raise RuntimeError("Flash SD is only supported on Windows, Linux, and macOS.")

    # balena-cli does not publish a native Windows ARM64 standalone package.
    # Windows ARM64 can run the x64 build through Windows emulation, so use it
    # as the supported fallback while keeping native ARM64 packages elsewhere.
    asset_arch_key = "x64" if platform_key == "windows" and arch_key == "arm64" else arch_key
    expected_fragment = f"{platform_key}-{asset_arch_key}-standalone.tar.gz"
    assets = release_data.get("assets", [])

    for asset in assets:
        name = asset.get("name", "").lower()
        if expected_fragment in name:
            return asset

    raise RuntimeError(
        f"Could not find a balena CLI asset for {platform_key}/{arch_key}."
    )


def _select_mr_fusion_asset(release_data: dict) -> dict:
    assets = release_data.get("assets", [])

    for asset in assets:
        lower_name = asset.get("name", "").lower()
        if re.fullmatch(r"mr-fusion-v[\d.]+\.img\.zip", lower_name):
            return asset

    for asset in assets:
        lower_name = asset.get("name", "").lower()
        if lower_name.endswith(".img.zip") and "mr-fusion" in lower_name:
            return asset

    raise RuntimeError("Could not find a Mr. Fusion .img.zip asset.")


def _select_superstation_asset(release_data: dict) -> dict:
    assets = release_data.get("assets", [])
    img_zip_assets = []

    for asset in assets:
        name = str(asset.get("name", "")).strip()
        lower_name = name.lower()
        if lower_name.endswith(".img.zip"):
            img_zip_assets.append(asset)

    if not img_zip_assets:
        raise RuntimeError("Could not find a SuperStation .img.zip asset.")

    def asset_sort_key(asset: dict) -> tuple[str, str]:
        updated = str(asset.get("updated_at") or "")
        created = str(asset.get("created_at") or "")
        timestamp = updated or created
        name = str(asset.get("name") or "")
        return (timestamp, name)

    return max(img_zip_assets, key=asset_sort_key)


def _get_local_archive_name(folder: Path) -> str | None:
    archive = _find_newest_matching_file(folder, "*.img.zip")
    if archive:
        return archive.name
    return None


def _read_mc_fusion_version() -> str | None:
    try:
        version = MC_FUSION_VERSION_FILE.read_text(encoding="utf-8").strip()
        return version or None
    except FileNotFoundError:
        return None
    except Exception:
        return None


def _write_mc_fusion_version(version: str) -> None:
    MC_FUSION_VERSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    MC_FUSION_VERSION_FILE.write_text(version.strip() + "\n", encoding="utf-8")


def _asset_timestamp(asset: dict) -> str:
    return str(asset.get("updated_at") or asset.get("created_at") or "")


def get_mc_fusion_image_status(log_callback: LogCallback | None = None) -> dict:
    ensure_tools_dirs(log_callback)

    local_version = _read_mc_fusion_version()
    local_img = _find_first_matching_file(MC_FUSION_DIR, "*.img")

    installed = bool(local_img)
    local_name = local_version or (local_img.name if local_img else None)

    latest_name = None
    up_to_date = None
    update_available = False

    try:
        latest_tag = _github_latest_release_tag_from_page(MC_FUSION_REPO)
        latest_name = latest_tag

        if installed:
            if local_version and latest_tag:
                up_to_date = local_version == latest_tag
                update_available = not up_to_date
            else:
                up_to_date = None
                update_available = False
    except Exception as e:
        _log(log_callback, f"Unable to check latest MC-Fusion release: {e}")
        latest_name = None
        if installed:
            up_to_date = None
            update_available = False

    return {
        "installed": installed,
        "up_to_date": up_to_date,
        "local_name": local_name,
        "latest_name": latest_name,
        "update_available": update_available,
    }


def get_superstation_image_status(log_callback: LogCallback | None = None) -> dict:
    ensure_tools_dirs(log_callback)

    local_archive_name = _get_local_archive_name(SUPERSTATION_DIR)
    local_img = _find_first_matching_file(SUPERSTATION_DIR, "*.img")

    installed = bool(local_img)
    local_name = local_archive_name or (local_img.name if local_img else None)

    latest_name = None
    up_to_date = None
    update_available = False

    try:
        release_data = _github_latest_release(SUPERSTATION_REPO)
        latest_asset = _select_superstation_asset(release_data)
        latest_name = str(latest_asset.get("name", "")).strip() or None

        if installed:
            if local_archive_name and latest_name:
                up_to_date = local_archive_name == latest_name
                update_available = not up_to_date
            else:
                up_to_date = None
                update_available = False
    except Exception as e:
        _log(log_callback, f"Unable to check latest SuperStation release: {e}")
        latest_name = None
        if installed:
            up_to_date = None
            update_available = False

    return {
        "installed": installed,
        "up_to_date": up_to_date,
        "local_name": local_name,
        "latest_name": latest_name,
        "update_available": update_available,
    }


def ensure_balena_cli(
    force_download: bool = False,
    log_callback: LogCallback | None = None,
) -> Path:
    if not is_flash_supported():
        raise RuntimeError("Flash SD is not supported on this platform.")

    ensure_tools_dirs(log_callback)

    if not force_download:
        try:
            exe = get_balena_executable()
            if platform.system() in ("Linux", "Darwin"):
                _make_executable(exe)
            _log(log_callback, f"Using existing balena CLI: {exe}")
            return exe
        except Exception:
            pass

    _log(log_callback, "Checking latest balena CLI release...")
    release_data = _github_latest_release(BALENA_REPO)
    asset = _select_balena_asset(release_data)

    archive_path = BALENA_DIR / asset["name"]

    _clear_directory_contents(BALENA_DIR)
    _download_file(asset["browser_download_url"], archive_path, log_callback)
    _extract_archive(archive_path, BALENA_DIR, log_callback)

    exe = get_balena_executable()
    if platform.system() in ("Linux", "Darwin"):
        _make_executable(exe)

    _log(log_callback, f"balena CLI ready: {exe}")
    return exe


def ensure_mr_fusion_image(
    force_download: bool = False,
    log_callback: LogCallback | None = None,
) -> Path:
    if not is_flash_supported():
        raise RuntimeError("Flash SD is not supported on this platform.")

    ensure_tools_dirs(log_callback)

    if not force_download:
        try:
            image = get_mr_fusion_image()
            _log(log_callback, f"Using existing Mr. Fusion image: {image}")
            return image
        except Exception:
            pass

    _log(log_callback, "Checking latest Mr. Fusion release...")
    release_data = _github_latest_release(MR_FUSION_REPO)
    asset = _select_mr_fusion_asset(release_data)

    archive_path = MR_FUSION_DIR / asset["name"]

    _clear_directory_contents(MR_FUSION_DIR)
    _download_file(asset["browser_download_url"], archive_path, log_callback)
    _extract_archive(archive_path, MR_FUSION_DIR, log_callback)

    image = get_mr_fusion_image()
    _log(log_callback, f"Mr. Fusion image ready: {image}")
    return image


def ensure_mc_fusion_image(
    force_download: bool = False,
    log_callback: LogCallback | None = None,
) -> Path:
    if not is_flash_supported():
        raise RuntimeError("Flash SD is not supported on this platform.")

    ensure_tools_dirs(log_callback)

    if not force_download:
        try:
            status = get_mc_fusion_image_status(log_callback=log_callback)
            if status.get("installed") and not status.get("update_available"):
                image = get_mc_fusion_image()
                _log(log_callback, f"Using existing MC-Fusion image: {image}")
                return image
        except Exception:
            pass

    _log(log_callback, "Checking latest MC-Fusion release...")
    latest_tag = _github_latest_release_tag_from_page(MC_FUSION_REPO)
    asset_url = _github_release_asset_download_url(
        MC_FUSION_REPO,
        latest_tag,
        MC_FUSION_ASSET_NAME,
    )

    _log(log_callback, f"Latest MC-Fusion release: {latest_tag}")

    archive_path = MC_FUSION_DIR / MC_FUSION_ASSET_NAME

    _clear_directory_contents(MC_FUSION_DIR)
    _download_file(asset_url, archive_path, log_callback)
    _extract_archive(archive_path, MC_FUSION_DIR, log_callback)
    _write_mc_fusion_version(latest_tag)

    image = get_mc_fusion_image()
    _log(log_callback, f"MC-Fusion image ready: {image}")
    return image


def ensure_superstation_image(
    force_download: bool = False,
    log_callback: LogCallback | None = None,
) -> Path:
    if not is_flash_supported():
        raise RuntimeError("Flash SD is not supported on this platform.")

    ensure_tools_dirs(log_callback)

    if not force_download:
        try:
            status = get_superstation_image_status(log_callback=log_callback)
            if status.get("installed") and not status.get("update_available"):
                image = get_superstation_image()
                _log(log_callback, f"Using existing SuperStation image: {image}")
                return image
        except Exception:
            pass

    _log(log_callback, "Checking latest SuperStation release...")
    release_data = _github_latest_release(SUPERSTATION_REPO)
    asset = _select_superstation_asset(release_data)

    asset_name = str(asset.get("name", "")).strip()
    asset_timestamp = _asset_timestamp(asset)
    if asset_timestamp:
        _log(log_callback, f"Latest SuperStation installer: {asset_name} ({asset_timestamp})")
    else:
        _log(log_callback, f"Latest SuperStation installer: {asset_name}")

    archive_path = SUPERSTATION_DIR / asset["name"]

    _clear_directory_contents(SUPERSTATION_DIR)
    _download_file(asset["browser_download_url"], archive_path, log_callback)
    _extract_archive(archive_path, SUPERSTATION_DIR, log_callback)

    image = get_superstation_image()
    _log(log_callback, f"SuperStation image ready: {image}")
    return image


def _run_subprocess(
    cmd: list[str],
    cwd: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    startupinfo = None
    if platform.system() == "Windows":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        cwd=str(cwd) if cwd else None,
        startupinfo=startupinfo,
        env=_clean_subprocess_env(),
    )


def _run_eject_command(
    cmd: list[str],
    log_callback: LogCallback | None = None,
) -> subprocess.CompletedProcess[str]:
    startupinfo = None
    if platform.system() == "Windows":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        startupinfo=startupinfo,
        env=_clean_subprocess_env(),
    )

    if result.stdout:
        for line in result.stdout.splitlines():
            cleaned_line = clean_output(line).strip()
            if cleaned_line:
                _log(log_callback, cleaned_line)

    if result.stderr:
        for line in result.stderr.splitlines():
            cleaned_line = clean_output(line).strip()
            if cleaned_line:
                _log(log_callback, cleaned_line)

    return result


def _eject_windows_drive(
    drive: str,
    log_callback: LogCallback | None = None,
) -> bool:
    match = re.match(r"^\\\\\.\\PhysicalDrive(\d+)$", drive, re.IGNORECASE)
    if not match:
        _log(log_callback, f"Automatic eject skipped: unsupported Windows drive path: {drive}")
        return False

    disk_number = match.group(1)
    script = f"""
$ErrorActionPreference = 'Stop'
$diskNumber = {disk_number}
$partitions = Get-Partition -DiskNumber $diskNumber | Where-Object {{ $_.DriveLetter }}
if (-not $partitions) {{
    Write-Output "No mounted drive letters found for PhysicalDrive$diskNumber."
    exit 2
}}
$shell = New-Object -ComObject Shell.Application
$success = $false
foreach ($partition in $partitions) {{
    $driveLetter = $partition.DriveLetter + ':'
    Write-Output "Ejecting $driveLetter..."
    $item = $shell.Namespace(17).ParseName($driveLetter)
    if ($item -ne $null) {{
        $item.InvokeVerb('Eject')
        Start-Sleep -Seconds 2
        $success = $true
    }} else {{
        Write-Output "Unable to find shell item for $driveLetter."
    }}
}}
if ($success) {{ exit 0 }}
exit 3
"""

    result = _run_eject_command(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            script,
        ],
        log_callback,
    )

    if result.returncode == 0:
        return True

    _log(log_callback, "Windows automatic eject did not complete.")
    return False


def _linux_child_block_devices(device: str) -> list[str]:
    result = _run_subprocess(["lsblk", "-nrpo", "NAME,TYPE", device])
    if result.returncode != 0:
        return []

    children: list[str] = []
    for raw_line in (result.stdout or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue

        parts = line.split(None, 1)
        if len(parts) != 2:
            continue

        name, block_type = parts
        if block_type in {"part", "crypt", "lvm"} and name != device:
            children.append(name)

    return children


def _eject_linux_drive(
    drive: str,
    log_callback: LogCallback | None = None,
) -> bool:
    if not shutil.which("lsblk"):
        _log(log_callback, "Automatic eject skipped: lsblk is not available.")
        return False

    partitions = _linux_child_block_devices(drive)

    if shutil.which("udisksctl"):
        for partition in partitions:
            _log(log_callback, f"Unmounting {partition}...")
            _run_eject_command(["udisksctl", "unmount", "-b", partition], log_callback)

        _log(log_callback, f"Powering off {drive}...")
        result = _run_eject_command(["udisksctl", "power-off", "-b", drive], log_callback)
        if result.returncode == 0:
            return True

        _log(log_callback, "udisksctl power-off did not complete.")

    for partition in partitions:
        _log(log_callback, f"Unmounting {partition}...")
        _run_eject_command(["umount", partition], log_callback)

    if shutil.which("eject"):
        _log(log_callback, f"Ejecting {drive}...")
        result = _run_eject_command(["eject", drive], log_callback)
        if result.returncode == 0:
            return True

    _log(log_callback, "Linux automatic eject did not complete.")
    return False


def _eject_macos_drive(
    drive: str,
    log_callback: LogCallback | None = None,
) -> bool:
    _log(log_callback, "Ejecting drive...")
    result = _run_eject_command(["diskutil", "eject", drive], log_callback)
    return result.returncode == 0


def eject_drive_after_flash(
    drive: str,
    log_callback: LogCallback | None = None,
) -> bool:
    system = platform.system()

    if system == "Windows":
        return _eject_windows_drive(drive, log_callback)

    if system == "Linux":
        return _eject_linux_drive(drive, log_callback)

    if system == "Darwin":
        return _eject_macos_drive(drive, log_callback)

    _log(log_callback, "Automatic eject is not supported on this platform.")
    return False


def _get_windows_drive_letter_map() -> dict[str, list[str]]:
    if platform.system() != "Windows":
        return {}

    cmd = [
        "powershell",
        "-NoProfile",
        "-Command",
        (
            "Get-Partition | "
            "Where-Object DriveLetter -ne $null | "
            "ForEach-Object { "
            "Write-Output ($_.DiskNumber.ToString() + '|' + $_.DriveLetter) "
            "}"
        ),
    ]

    result = _run_subprocess(cmd)
    if result.returncode != 0:
        return {}

    drive_letter_map: dict[str, list[str]] = {}

    for raw_line in (result.stdout or "").splitlines():
        line = raw_line.strip()
        if not line or "|" not in line:
            continue

        disk_number, drive_letter = line.split("|", 1)
        disk_number = disk_number.strip()
        drive_letter = drive_letter.strip()

        if not disk_number or not drive_letter:
            continue

        drive_letter_map.setdefault(disk_number, []).append(f"{drive_letter}:")

    return drive_letter_map


def _build_drive_display_name(
    device: str,
    description: str = "",
    size: int | None = None,
    windows_drive_letter_map: dict[str, list[str]] | None = None,
) -> str:
    parts: list[str] = []

    if platform.system() == "Windows":
        display_prefix = device

        match = re.match(r"^\\\\\.\\PhysicalDrive(\d+)$", device, re.IGNORECASE)
        if match and windows_drive_letter_map is not None:
            disk_number = match.group(1)
            letters = windows_drive_letter_map.get(disk_number, [])
            if letters:
                display_prefix = " / ".join(letters)

        if display_prefix:
            parts.append(display_prefix)
    else:
        if device:
            parts.append(device)

    if description:
        parts.append(description)

    if size:
        try:
            size_gb = float(size) / (1024 ** 3)
            parts.append(f"{size_gb:.1f} GB")
        except Exception:
            pass

    return " - ".join(parts) if parts else "Unknown drive"


def _size_text_to_bytes(size_text: str) -> int | None:
    match = re.match(r"^\s*([\d.]+)\s*([KMGTP]?B)\s*$", size_text, re.IGNORECASE)
    if not match:
        return None

    value = float(match.group(1))
    unit = match.group(2).upper()

    multipliers = {
        "KB": 1024,
        "MB": 1024 ** 2,
        "GB": 1024 ** 3,
        "TB": 1024 ** 4,
        "PB": 1024 ** 5,
    }

    return int(value * multipliers.get(unit, 1))


def _parse_available_drives_output(output: str) -> list[dict]:
    drives: list[dict] = []

    lines = [line.strip() for line in output.splitlines() if line.strip()]
    if not lines:
        return drives

    for line in lines:
        upper_line = line.upper()
        if "DEVICE" in upper_line and "SIZE" in upper_line:
            continue

        match = re.match(
            r"^(?P<device>\S+)\s+(?P<size>[\d.]+\s*[KMGTP]?B)\s+(?P<description>.+)$",
            line,
            re.IGNORECASE,
        )
        if not match:
            continue

        device = match.group("device").strip()
        size_text = match.group("size").strip()
        description = match.group("description").strip()

        drives.append(
            {
                "device": device,
                "size": _size_text_to_bytes(size_text),
                "description": description,
            }
        )

    return drives


def list_available_drives(
    log_callback: LogCallback | None = None,
) -> list[dict]:
    if not is_flash_supported():
        return []

    if not has_balena_cli():
        raise RuntimeError("balena CLI is not downloaded yet. Download it first.")

    balena_exe = get_balena_executable()
    _log(log_callback, "Refreshing available drives...")

    result = _run_subprocess(
        [str(balena_exe), "util", "available-drives"],
        cwd=balena_exe.parent,
    )

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stdout = (result.stdout or "").strip()
        combined = "\n".join(part for part in [stderr, stdout] if part).strip()
        raise RuntimeError(combined or "Failed to get available drives.")

    stdout = (result.stdout or "").strip()
    if not stdout:
        return []

    _log(log_callback, "Raw balena drive output:")
    for line in stdout.splitlines():
        _log(log_callback, line)

    drives = _parse_available_drives_output(stdout)

    windows_drive_letter_map: dict[str, list[str]] = {}
    if platform.system() == "Windows":
        windows_drive_letter_map = _get_windows_drive_letter_map()

    for drive in drives:
        device = str(drive.get("device", "")).strip()
        description = str(drive.get("description", "")).strip()
        size = drive.get("size")

        drive["display_name"] = _build_drive_display_name(
            device=device,
            description=description,
            size=size,
            windows_drive_letter_map=windows_drive_letter_map,
        )

    _log(log_callback, f"Parsed {len(drives)} drive(s).")
    return drives


def flash_image(
    image_path: str | Path,
    drive: str,
    log_callback: LogCallback | None = None,
    password: str | None = None,
) -> None:
    _ensure_flash_privileges()

    image_path = Path(image_path)
    if not image_path.exists():
        raise RuntimeError(f"Image file not found: {image_path}")

    if not drive:
        raise RuntimeError("No drive selected.")

    if not has_balena_cli():
        raise RuntimeError("balena CLI is not downloaded yet. Download it first.")

    balena_exe = get_balena_executable()

    cmd = [
        str(balena_exe),
        "local",
        "flash",
        str(image_path),
        "--drive",
        drive,
        "--yes",
    ]

    if platform.system() == "Darwin":
        cmd = ["sudo", "-S"] + cmd

    _log(log_callback, f"Starting flash: {image_path.name}")
    _log(log_callback, f"Target drive: {drive}")

    clean_env = _clean_subprocess_env()

    if platform.system() == "Darwin":
        _log(log_callback, "Unmounting disk before flash...")
        subprocess.run(
            ["diskutil", "unmountDisk", drive],
            capture_output=True,
            text=True,
            env=clean_env,
        )

    original_autoplay_value = None
    if platform.system() == "Windows":
        original_autoplay_value = _disable_windows_autoplay(log_callback)

    startupinfo = None
    if platform.system() == "Windows":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    process = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE if platform.system() == "Darwin" else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        cwd=str(balena_exe.parent),
        startupinfo=startupinfo,
        bufsize=1,
        env=clean_env,
    )

    if platform.system() == "Darwin" and password is not None:
        assert process.stdin is not None
        process.stdin.write(password + "\n")
        process.stdin.flush()
        process.stdin.close()

    output_lines: list[str] = []

    try:
        assert process.stdout is not None

        for raw_line in process.stdout:
            cleaned_line = clean_output(raw_line).strip()
            if not cleaned_line:
                continue

            lower_line = cleaned_line.lower()

            if "source and destination checksums do not match" in lower_line:
                continue

            output_lines.append(cleaned_line)
            _log(log_callback, cleaned_line)

        return_code = process.wait()
        combined_output = "\n".join(output_lines).lower()

        symbol_error_markers = ["symbol lookup error", "undefined symbol"]
        bad_drive_markers = ["couldn't clean the drive", "could not clean the drive"]
        password_error_markers = [
            "incorrect password attempt",
            "no password was provided",
            "sorry, try again",
        ]
        permission_error_markers = [
            "eacces",
            "try running this command with elevated privileges",
            "administrator privileges",
            "access is denied",
            "permission denied",
        ]
        generic_error_markers = ["error:"]

        if any(marker in combined_output for marker in symbol_error_markers):
            raise RuntimeError(
                "Flash failed because an external Linux system command could not start correctly.\n\n"
                "This is usually caused by a bundled PyInstaller library conflicting with a system library.\n"
                "MiSTer Companion tried to use a cleaned subprocess environment, but balena CLI still failed.\n\n"
                f"Exit code: {return_code}"
            )

        if any(marker in combined_output for marker in bad_drive_markers):
            raise RuntimeError(
                "Flash failed: the drive could not be prepared for flashing.\n\n"
                "This usually means the SD card or card reader is faulty, write-protected, or in a bad "
                "state. Try a different SD card or a different USB card reader, then try again."
            )

        if platform.system() == "Darwin" and any(
            marker in combined_output for marker in password_error_markers
        ):
            raise RuntimeError(
                "Incorrect password.\n\n"
                "MiSTer Companion could not authenticate with the password you entered. Please try "
                "again and make sure it's your macOS login password."
            )

        if any(marker in combined_output for marker in permission_error_markers):
            if platform.system() == "Windows":
                raise RuntimeError(
                    "Administrator privileges are required.\n\n"
                    "Please restart MiSTer Companion as Administrator and try again."
                )
            if platform.system() == "Linux":
                raise RuntimeError(
                    "Root privileges are required.\n\n"
                    "Please run MiSTer Companion with sudo or pkexec and try again."
                )
            if platform.system() == "Darwin":
                raise RuntimeError(
                    "Full Disk Access is required.\n\n"
                    "macOS blocked access to the drive. Open System Settings → Privacy & Security → "
                    "Full Disk Access, enable it for MiSTer Companion (or Terminal, if running from "
                    "source), then try again."
                )
            raise RuntimeError("Flash failed. balena CLI reported a permission or drive access error.")

        if any(marker in combined_output for marker in generic_error_markers):
            raise RuntimeError(
                "Flash failed. balena CLI reported an error.\n\nCheck the log above for details."
            )

        if return_code != 0:
            raise RuntimeError(f"Flash failed with exit code {return_code}.")

        _log(log_callback, "Flash completed successfully.")

        _log(log_callback, "Safely ejecting drive...")
        if eject_drive_after_flash(drive, log_callback):
            _log(log_callback, "Drive safely ejected.")
        else:
            _log(
                log_callback,
                "Flash completed, but the drive could not be ejected automatically. "
                "Please eject it safely using your operating system before removing it.",
            )

    finally:
        if process.stdout is not None:
            try:
                process.stdout.close()
            except Exception as e:
                _log(log_callback, f"Failed to close process stdout: {e}")

        if platform.system() == "Windows":
            try:
                _log(log_callback, "Waiting briefly before restoring Windows settings...")
                time.sleep(3.0)
                _log(log_callback, "Restoring Windows AutoPlay setting...")
                _restore_windows_autoplay(original_autoplay_value, log_callback)
                _log(log_callback, "Windows AutoPlay restore complete.")
            except Exception as e:
                _log(log_callback, f"Failed to restore Windows settings: {e}")